

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext


object HelloSpark {  
  
  def main(arg : Array[String]) {
    
    println("Calling My HelloSpark......")    
    val sparkConf = new SparkConf().setAppName("My First App").setMaster("local") 
    val sparkContext = new SparkContext(sparkConf)    
    //val filename="/root/Test/In/Sample.txt"    
    val filename="file:/C:/Users/dnagaraj/Sample.txt"
   // val filename="\\D-113096612-BLR\\ssusanph\\Sample.txt.txt"
    val lines = sparkContext.textFile(filename).cache()    
    val linecount= lines.count()
    println(" lines RDD " + lines.collect().apply(0).toString())
        println("There are " + linecount + " lines in " + filename) 
    println("exiting HelloSpark......")
  }
   
}