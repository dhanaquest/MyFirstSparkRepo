package com.test.spark.example.myspark_example1;

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext


object HelloSpark {  
  
  def main(arg : Array[String]) {
    
    println("Calling My HelloSpark......")    
    val sparkConf = new SparkConf().setAppName("My First App")    
    val sparkContext = new SparkContext(sparkConf)    
    //val filename="/root/Test/In/Sample.txt"    
    val filename="C:\\Users\\dnagaraj\\Sample.txt"
    val lines = sparkContext.textFile(filename).cache()    
    val linecount= lines.count()
        println("There are $linecount lines in $fileName") 
    println("exiting HelloSpark......")
  }
   
}