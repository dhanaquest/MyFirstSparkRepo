package com.test.spark.example.myspark_example1

object Test {
    def main(arg : Array[String]) {
    
    println("Calling My HelloSpark......")    
    }
}